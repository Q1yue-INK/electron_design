#include "ctl.h"


// samp_rate 100.0Hz
//11*4*30 ��תһȦ������������ 
#define encod2rpm 50.0/11.0 //100 * 60 / 1320 = 50/11	
#define ASR_K 36	//K * pwm_period = 0.03 * 1200 = 36
#define ASR_a_1 0.24
#define ASR_a_2 -0.23

//	G(z) = K * ( a_1 * z - a_2) /(z - 1 )  = D(z)/e(z)
//	G(z) = K * ( 0.24 z - 0.23) /(z - 1)
//	D = D/z +0.24e -0.23e/z
//	D(k) = D(k-1) +0.24e(k)-0.23 * e(k-1)	 

// float e1 = 0.0, e2 = 0.0;
// float D1 = 0.0, D2 = 0.0;

//e = n* - n    [rpm]
//n = encode_measure  * encod2rpm
//dutycycle = D(k) * ASR_K , -pwm_period < dutycycle < pwm_period

// float ek=0.0, e1=0.0;//e1=e(k-1),e2=e(k-2) ת�����
// float Dk=0.0, D1=0.0;//ռ�ձ� 

float ek[4]={0.0};
//float e1[4]={0.0};
float Dk[4]={0.0};
//float D1[4]={0.0};
float B[4]={0.0};

int ASR(int pulse_num, int goalrpm,int i, int flag)
{
		int dutycycle = 0;
		if (flag == 1)
		{
		    float nrpm = 0.0;
				
				float per;
				per = (float) pwm_per;

				nrpm = pulse_num * encod2rpm;
			
				// printf("%f``",nrpm);
			
				ek[i] = goalrpm - nrpm;
				Dk[i] =ASR_K * ASR_a_1 * ek[i] + B[i];
				//Dk[i] =ASR_K * (ASR_a_1*ek[i] + ASR_a_2 * e1[i]) + D1[i];
				// printf("org=%f---",Dk);
				
				
				if (Dk[i]>per) 
				{
						Dk[i] = per;
				}
				else if (Dk[i]<-per)
				{
						Dk[i] = -per;
				}
				
				dutycycle = (int)(Dk[i]);
				//e1[i] = ek[i];
				//D1[i] = Dk[i];
				B[i] = Dk[i] + ASR_K * ASR_a_2 * ek[i];
				
		}	
		else if (flag == 0)
		{
				ek[i] = 0;
				Dk[i] = 0;
				B[i] = 0;
				dutycycle = 0;
		}
		return dutycycle;

}
