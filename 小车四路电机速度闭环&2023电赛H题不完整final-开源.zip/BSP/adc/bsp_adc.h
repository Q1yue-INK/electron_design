/**
* @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
* @file         bsp_adc.h	
* @author       liusen
* @version      V1.0
* @date         2017.07.17
* @brief        ADC
* @details      
* @par History  ������˵��
*                 
* version:		liusen_20170717
*/

#ifndef __BSP_ADC_H__
#define __BSP_ADC_H__

#include "AllHeader.h"
#include "stm32f10x.h"


void Adc_Init(void);

static u16 Get_Adc(u8 ch);
static u16 Get_Adc_Average(u8 ch, u8 times);
float Get_Measure_Volotage(void);
void voltage_warning(void);

void collect_signal(void);


#endif

