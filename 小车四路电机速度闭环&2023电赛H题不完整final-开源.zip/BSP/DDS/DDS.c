#include "DDS.h"



//AD9833��IO�ܽų�ʼ��
void AD9833_GPIO_Init() 
{

    GPIO_InitTypeDef GPIO_InitStructure ; 
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��PB�˿�ʱ��
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	 //ʹ��PB�˿�ʱ��

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0| GPIO_Pin_10| GPIO_Pin_12 ; //PB0,10,12���ڿ���DDS1

    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz ; 

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ; 		//�������

    GPIO_Init(GPIOB ,&GPIO_InitStructure);
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8; //PC4���ڿ���DDS2 pc678
	
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz ; 

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ; 		//�������
	
		GPIO_Init(GPIOC ,&GPIO_InitStructure);
} 

//AD9833_1������д��
void AD9833_SPI_Write1(u16 DDS_data)
{
	u16 data=DDS_data;
	u8 i=0;
    AD9833_SCLK_1=1; 
    AD9833_FSYNC_1=0 ; 
	for(i = 0;i < 16;i ++)
	{
      if(data & 0x8000){
				AD9833_SDATA_1=1; 
			}
      else{ 
          AD9833_SDATA_1=0; 
			}
      AD9833_SCLK_1=0; 
      data<<= 1; 
      AD9833_SCLK_1=1;  
	}
    AD9833_SDATA_1=1; 
    AD9833_FSYNC_1=1; 
}

//AD9833_2������д��
void AD9833_SPI_Write2(u16 DDS_data)
{
	u16 data=DDS_data;
	u8 i=0;
    AD9833_SCLK_2=1; 
    AD9833_FSYNC_2=0 ; 
	for(i = 0;i < 16;i ++)
	{
      if(data & 0x8000){
				AD9833_SDATA_2=1; 
			}
      else{ 
          AD9833_SDATA_2=0; 
			}
      AD9833_SCLK_2=0; 
      data<<= 1; 
      AD9833_SCLK_2=1;  
	}
    AD9833_SDATA_2=1; 
    AD9833_FSYNC_2=1; 
}

//AD9833�����ּ���
void AD9833_SetFreq1(uint32_t _freq)
{
	uint32_t freq;
	uint16_t lsb_14bit;
	uint16_t msb_14bit;
	uint8_t freq_number = 0;
	freq = (uint32_t)(268435456.0 / AD9833_SYSTEM_CLOCK * _freq);
	lsb_14bit = (uint16_t)freq;
	msb_14bit = (uint16_t)(freq >> 14);
	if(freq_number == FREQ_0)
	{
		lsb_14bit &= ~(1U<<15);//0111 1111 1111 1111 �Ȱѵ�15λ��0,����λ����
		lsb_14bit |= 1<<14;    //0100 0000 0000 0000 �ٰѵ�14λ��1,����λ���� �������01xx xxxx xxxx xxxx
		msb_14bit &= ~(1U<<15); //ͬ��
		msb_14bit |= 1<<14;
	}
	else
	{
		lsb_14bit &= ~(1<<14); //1011 1111 1111 1111 �Ȱѵ�14λ��0,����λ����
		lsb_14bit |= 1U<<15;   //1000 0000 0000 0000 �ٰѵ�15λ��1,����λ���� �������10xx xxxx xxxx xxxx
		msb_14bit &= ~(1<<14); //ͬ��
		msb_14bit |= 1U<<15;
	}
	AD9833_SPI_Write1(lsb_14bit);
	AD9833_SPI_Write1(msb_14bit);
}

//AD9833�����ּ���
void AD9833_SetFreq2(uint32_t _freq)
{
	uint32_t freq;
	uint16_t lsb_14bit;
	uint16_t msb_14bit;
	uint8_t freq_number = 0;
	freq = (uint32_t)(268435456.0 / AD9833_SYSTEM_CLOCK * _freq);
	lsb_14bit = (uint16_t)freq;
	msb_14bit = (uint16_t)(freq >> 14);
	if(freq_number == FREQ_0)
	{
		lsb_14bit &= ~(1U<<15);//0111 1111 1111 1111 �Ȱѵ�15λ��0,����λ����
		lsb_14bit |= 1<<14;    //0100 0000 0000 0000 �ٰѵ�14λ��1,����λ���� �������01xx xxxx xxxx xxxx
		msb_14bit &= ~(1U<<15); //ͬ��
		msb_14bit |= 1<<14;
	}
	else
	{
		lsb_14bit &= ~(1<<14); //1011 1111 1111 1111 �Ȱѵ�14λ��0,����λ����
		lsb_14bit |= 1U<<15;   //1000 0000 0000 0000 �ٰѵ�15λ��1,����λ���� �������10xx xxxx xxxx xxxx
		msb_14bit &= ~(1<<14); //ͬ��
		msb_14bit |= 1U<<15;
	}
	AD9833_SPI_Write2(lsb_14bit);
	AD9833_SPI_Write2(msb_14bit);
}

void AD9833_phase1(u16 deg){
	u16 phase_reg = 0;
	phase_reg = deg*2048/180;
	phase_reg = phase_reg & 0x0fff;
	phase_reg |= 0xD000;
	AD9833_SPI_Write1(phase_reg);
	
}

void AD9833_phase2(u16 deg){
	u16 phase_reg = 0;
	phase_reg = deg*512/45;
	phase_reg = phase_reg & 0x0fff;
	phase_reg |= 0xD000;
	AD9833_SPI_Write2(phase_reg);
	
}

//����DDS1	
void set_DDS1(uint32_t _freq,int deg,int label){

		if (label == 0 )
		{
			AD9833_SPI_Write1(0x2100);
		}else {	AD9833_SPI_Write1(0x2122);}
		AD9833_SetFreq1(_freq);
		AD9833_phase1(deg);
		// AD9833_SPI_Write1(0xD000);
		// AD9833_SPI_Write1(0x2000);				//reset
		
}

//����DDS2
void set_DDS2(uint32_t _freq,int deg,int label){

		if (label == 0 )
		{
			AD9833_SPI_Write2(0x2100);
		}else 	{AD9833_SPI_Write2(0x2122);}
		// AD9833_SPI_Write2(0x2100);
		AD9833_SetFreq2(_freq);
		AD9833_phase2(deg);
		//AD9833_SPI_Write2(0xD000);
		//AD9833_SPI_Write2(0x2000);				//reset
		

}

void resetDDS(void){
		u16 data = DDS_reset;
		u8 i=0;
    AD9833_SCLK_1=1;
		AD9833_SCLK_2=1;	
	
    AD9833_FSYNC_1=0 ;
		AD9833_FSYNC_2=0 ;
		for(i = 0;i < 16;i ++)
		{
      if(data & 0x8000){
				AD9833_SDATA_1=1; 
				AD9833_SDATA_2=1; 
			}
      else{ 
          AD9833_SDATA_1=0;
					AD9833_SDATA_2=0;
			}
      AD9833_SCLK_1=0; 
			AD9833_SCLK_2=0; 
      data<<= 1; 
      AD9833_SCLK_1=1;
			AD9833_SCLK_2=1;			
	}
    AD9833_SDATA_1=1;
		AD9833_SDATA_2=1;	
    AD9833_FSYNC_1=1;
		AD9833_FSYNC_2=1;
		data = DDS_disreset;
		i=0;
    AD9833_SCLK_1=1;
		AD9833_SCLK_2=1;	
	
    AD9833_FSYNC_1=0 ;
		AD9833_FSYNC_2=0 ;
		for(i = 0;i < 16;i ++)
		{
      if(data & 0x8000){
				AD9833_SDATA_1=1; 
				AD9833_SDATA_2=1; 
			}
      else{ 
          AD9833_SDATA_1=0;
					AD9833_SDATA_2=0;
			}
      AD9833_SCLK_1=0; 
			AD9833_SCLK_2=0; 
      data<<= 1; 
      AD9833_SCLK_1=1;
			AD9833_SCLK_2=1;			
	}
   
}


