#ifndef __DDS_H
#define __DDS_H

#include "AllHeader.h"
#include "stm32f10x.h"

#define AD9833_FSYNC_1 	PBout(0)
#define AD9833_SCLK_1 	PBout(10)
#define AD9833_SDATA_1 	PBout(12)

#define AD9833_FSYNC_2 	PCout(6)
#define AD9833_SCLK_2 	PCout(7)
#define AD9833_SDATA_2 	PCout(8)

#define AD9833_SYSTEM_CLOCK 4000000.0

#define FREQ_0 0

#define sin_ctr 0x0000
#define tri_ctr 0x0000              //���������⣬Ҫ������ǲ��ǵ�ȥ��һ���ֲ�
#define DDS_reset 0x2100
#define DDS_disreset 0x2000

// Ƶ�ʿ�����0b10.������LSB��0b01.������MSB






void AD9833_GPIO_Init(void);

void AD9833_SPI_Write1(u16 DDS_data);
void AD9833_SPI_Write2(u16 DDS_data);

void AD9833_SetFreq1(uint32_t _freq);
void AD9833_SetFreq2(uint32_t _freq);

void AD9833_phase1(u16 deg);
void AD9833_phase2(u16 deg);

void set_DDS1(uint32_t _freq,int deg,int label);
void set_DDS2(uint32_t _freq,int deg,int label);

void resetDDS(void);


#endif

