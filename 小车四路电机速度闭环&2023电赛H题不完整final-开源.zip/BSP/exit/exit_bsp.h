#ifndef _BSP_EXIT_H
#define _BSP_EXIT_H

#include "AllHeader.h"
#include "stm32f10x.h"




void EXIT_Key_Config(void);


#endif 











