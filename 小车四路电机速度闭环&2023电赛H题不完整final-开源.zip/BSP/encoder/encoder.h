#ifndef _ENCODER_H
#define _ENCODER_H

#include "AllHeader.h"
#include "stm32f10x.h"



// void Encoder_Init_TIM2(void);
// void Encoder_Init_TIM3(void);
// void Encoder_Init_TIM4(void);
// void Encoder_Init_TIM5(void);
int Read_Encoder(u8 TIMX);

void TIM6_init(u16 per,u16 psc);


#endif
