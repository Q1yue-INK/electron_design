#ifndef _BSP_PINREAD_H
#define _BSP_PINREAD_H

#include "AllHeader.h"
#include "stm32f10x.h"


int pincount(void);


#endif /*_BSP_EXIT_H*/

