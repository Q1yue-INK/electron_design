#ifndef _clkout_H
#define _clkout_H

#include "AllHeader.h"



void Init_TIM5(u16 per,u16 psc);


#endif

