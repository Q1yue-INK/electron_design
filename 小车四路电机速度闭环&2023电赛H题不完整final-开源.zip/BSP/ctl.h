#include "AllHeader.h"

int ASR(int pulse_num, int goalrpm, int i, int flag);

