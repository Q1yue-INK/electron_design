#ifndef __AllHeader_H
#define __AllHeader_H

#define DEBUG_USARTx USART1

#define pwm_per 1200-1 //pwm��TIM8����
#define pwm_psc 3-1     //pmw��TIM8��Ƶϵ��
#define N 1024

#include "stm32f10x.h"
// ����ȫ���ⲿ����
extern volatile int vel_goal[4];                //Ŀ���ٶ�ֵ
extern volatile int stop_flag;                  //ͣ����ı�־ 1:�ٶȱջ� 0:�ܺ��ƶ���ֹͣ�����
extern volatile u16 vol[1024];
extern volatile int f1, f2, label1, label2;	

//���ܿ���  1:�� 0:�ر�
#define LCD_SWITCH    0
#define IMU_SWITCH 		0 
#define FLASH_SWITCH  0 
#define RGB_SWITCH		0
#define DEBUG_SWITCH  1



#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include "stdint.h"

//#include "stm32f10x_gpio.h"
//#include "stm32f10x_pwr.h"
//#include "stm32f10x_bkp.h"

#include "bsp.h"
#include "bsp_common.h"
#include "delay.h"

#include "bsp_key.h"

#include "bsp_icm20607.h"
#include "IOI2C.h"

#include "lcd.h"
#include "lcd_init.h"

#include "bsp_spi.h"
#include "bsp_w25q64.h"

#include "bsp_RGB.h"
#include "bsp_usart.h"

#include "pwm.h"

#include "encoder.h"

#include "ctl.h"

#include "bsp_adc.h"


#include "exit_bsp.h"

#include "pinread.h"

#include "clkout.h"

#include "DDS.h"

//APP�ļ��µĺ���
/********�ⲿflash���*********/
u8 detcet_flash(void);
void flash_test(void);
void show_flash(void);

/**********IMU���************/
void imu_test(void);

extern unsigned char ICM_ADDRESS;




#endif


